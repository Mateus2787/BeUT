import com.mongodb.client.MongoClients
import com.mongodb.client.MongoClient
import com.mongodb.client.MongoDatabase
import org.bson.Document

class MongoDBManager {
    private val mongoClient: MongoClient =
        MongoClients.create("mongodb://localhost:27017")
    private val database: MongoDatabase = mongoClient.getDatabase("clusterPI")
    private val collection = database.getCollection("sua_colecao")

    fun inserirDocumento(chave: String, valor: String) {
        val document = Document(chave, valor)
        collection.insertOne(document)
    }
}